
def input01(s001,s002,s004):
    d001 = raw_input('Apakah hewan terlihat menggaruk garuk badan berlebihan ? ')
    return d004

    def input02(s001,s003,s006,s015,s023,s027):
d002 = raw_input('apakah hewan anda terdapat bulu rontok berlebihan?')
    return d002

    def input04(s001,s005,s022,):
    d004 = raw_input('apakah hewan anda terlihat bernanah dan bau?')
    return d004

    def input08(s020,s028,ss31):
        d008 = raw_input('Apakah hewan anda terlihat menggigit talapak kaki?')
        return d008

        def inputd009(s011,s012,):
            d009 = raw_input('Apakah hewan anda terkena deman atau tidak ada nafsu makan?')
            return d009

            inp01 = input01()
            inp02 = input02()
            inp03 = input04()
            inp05 = input08()
            inp05 = input09()


            if inp01 != inp02:
                print('the result is'+inp01,inp02,inp03,inp05)
            else:
                print("Penyakit tidak ditemukan")
                SystemExit
